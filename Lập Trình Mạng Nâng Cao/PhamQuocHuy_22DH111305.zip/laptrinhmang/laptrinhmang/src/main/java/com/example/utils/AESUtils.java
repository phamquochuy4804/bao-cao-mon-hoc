package com.example.utils;

import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AESUtils {

    private static final String ALGORITHM = "AES/CBC/PKCS5Padding"; //Thuật toán AES dùng ở đây là: AES với chế độ CBC (Cipher Block Chaining) và bù padding kiểu PKCS5.
    private static final int KEY_SIZE = 256; //KEY_SIZE = 256 → AES 256-bit.

    // Generate a new AES key
    public static SecretKey generateAESKey() throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(KEY_SIZE, SecureRandom.getInstanceStrong()); //Tạo khóa AES 256-bit sử dụng KeyGenerator và SecureRandom.
        return keyGen.generateKey();
    }

    // Generate a new IV
    public static byte[] generateIV() {
        byte[] iv = new byte[16]; // 16 bytes for AES
        //Tạo một mảng IV ngẫu nhiên dài 16 byte (AES block size = 128 bit = 16 byte).
        new SecureRandom().nextBytes(iv);
        return iv;
    }

    // Encrypt data using AES
    public static byte[] encrypt(byte[] data, SecretKey secretKey, byte[] iv) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        //Mã hóa dữ liệu (dưới dạng byte[]) bằng AES + CBC + PKCS5Padding.
        //Dùng khóa bí mật secretKey và iv sinh ra từ trước.
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(iv));
        return cipher.doFinal(data);
    }

    // Decrypt data using AES
    public static byte[] decrypt(byte[] encryptedData, SecretKey secretKey, byte[] iv) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        //Giải mã dữ liệu mã hóa AES.
        //Yêu cầu đúng khóa và đúng IV đã dùng khi mã hóa.
        cipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(iv));
        return cipher.doFinal(encryptedData);
    }

    // Convert SecretKey to Base64 String
    public static String keyToBase64(SecretKey secretKey) {
        return Base64.getEncoder().encodeToString(secretKey.getEncoded());
    }

    // Convert Base64 String to SecretKey
    public static SecretKey base64ToKey(String base64Key) {
        byte[] decodedKey = Base64.getDecoder().decode(base64Key);
        return new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");
    }

    // Convert byte[] to Base64 String
    public static String bytesToBase64(byte[] bytes) {
        return Base64.getEncoder().encodeToString(bytes);
    }

    // Convert Base64 String to byte[]
    public static byte[] base64ToBytes(String base64String) {
        return Base64.getDecoder().decode(base64String);
    }
}


