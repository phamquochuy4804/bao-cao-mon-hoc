package com.example.server;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import io.netty.channel.ChannelHandlerContext;

public class SubdomainScanner {
    private static final List<String> SUBDOMAIN_LIST;
    private static final int MAX_SUBDOMAINS_TO_CHECK = 1000;

    private final String domain;
    private final ChannelHandlerContext ctx;
    private final Consumer<ChannelHandlerContext> onComplete;

    private final AtomicInteger scannedCount = new AtomicInteger(0);
    private final int totalSubdomains;
    private volatile boolean isRunning = false;

    // Static block to load the subdomain list only once
    static {
        List<String> tempSubdomainList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("subdomains-top1million-110000.txt"))) {
            String line;
            int count = 0;
            while ((line = reader.readLine()) != null && count < MAX_SUBDOMAINS_TO_CHECK) {
                tempSubdomainList.add(line.trim());
                count++;
            }
        } catch (IOException e) {
            System.err.println("Error loading subdomain list from file: " + e.getMessage());
            // Add some default subdomains if file loading fails
            tempSubdomainList.addAll(Arrays.asList(
                "www", "mail", "ftp", "localhost", "webmail", "smtp", "pop", "ns1", "webdisk",
                "ns2", "cpanel", "whm", "autodiscover", "autoconfig", "m", "imap", "test",
                "ns", "blog", "pop3", "dev", "www2", "admin"
            ));
        }
        SUBDOMAIN_LIST = Collections.unmodifiableList(tempSubdomainList);
    }
    
    public SubdomainScanner(String domain, ChannelHandlerContext ctx, Consumer<ChannelHandlerContext> onComplete) {
        this.domain = normalizeDomain(domain);
        this.ctx = ctx;
        this.onComplete = onComplete; // Callback to run when scanning is finished
        this.totalSubdomains = SUBDOMAIN_LIST.size();
    }

    private String normalizeDomain(String rawDomain) {
        if (rawDomain == null || rawDomain.trim().isEmpty()) {
            return "";
        }
        String d = rawDomain.trim().toLowerCase();
        if (d.startsWith("https://")) {
            d = d.substring(8);
        } else if (d.startsWith("http://")) {
            d = d.substring(7);
        }
        int slashIndex = d.indexOf('/');
        if (slashIndex != -1) {
            d = d.substring(0, slashIndex);
        }
        return d;
    }

    public void startScan() {
        if (domain.isEmpty()) {
            ctx.writeAndFlush("{\"status\":\"error\",\"message\":\"Invalid domain provided.\"}");
            onComplete.accept(ctx);
            return;
        }

        isRunning = true;
        // Run the scan in a new thread to avoid blocking the Netty event loop
        new Thread(() -> {
            List<String> foundSubdomains = new ArrayList<>();
            
            // Using parallel stream for concurrency
            SUBDOMAIN_LIST.parallelStream().forEach(subdomain -> {
                if (!isRunning) return; // Stop if interrupted

                String fullDomain = subdomain + "." + this.domain;
                if (checkSubdomain(fullDomain)) {
                    synchronized (foundSubdomains) {
                        foundSubdomains.add(fullDomain);
                    }
                    // Send found subdomain immediately to the client
                    String foundMsg = String.format("{\"status\":\"scan_result\",\"message\":\"Found: %s\"}", fullDomain);
                    ctx.writeAndFlush(foundMsg);
                }
                scannedCount.incrementAndGet();
            });

            if (!isRunning) {
                 System.out.println("Scan for " + domain + " was cancelled.");
                 return;
            }

            // Send final summary
            StringBuilder resultText = new StringBuilder();
            if (foundSubdomains.isEmpty()) {
                resultText.append("No subdomains found for ").append(this.domain);
            } else {
                resultText.append("Found ").append(foundSubdomains.size()).append(" subdomains for ").append(this.domain);
            }

            // Final message indicating completion
            String finalMsg = String.format("{\"status\":\"scan_complete\",\"message\":\"%s\"}", resultText.toString());
            ctx.writeAndFlush(finalMsg);
            
            isRunning = false;
            // Execute the callback to notify ServerHandler that this scan is done
            onComplete.accept(ctx);

        }).start();
    }

    private boolean checkSubdomain(String subdomain) {
        try {
            InetAddress.getByName(subdomain);
            return true;
        } catch (UnknownHostException e) {
            return false;
        }
    }
    
    public double getScanProgress() {
        if (totalSubdomains == 0) {
            return 100.0;
        }
        return (double) scannedCount.get() * 100.0 / totalSubdomains;
    }

    public void stopScan() {
        this.isRunning = false;
    }
}