package com.example.server.admin;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.example.database.DatabaseManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;

public class ServerAdminGUI extends JFrame {
    private DatabaseManager dbManager;
    private JTable usersTable;
    private JTable keysTable;
    private JTable chatHistoryTable;
    private DefaultTableModel usersModel;
    private DefaultTableModel keysModel;
    private DefaultTableModel chatHistoryModel;
    private JTextArea logArea;
    
    // Buttons
    private JButton refreshButton;
    private JButton deleteUserButton;
    private JButton deleteKeyButton;
    private JButton clearChatButton;
    private JButton exportKeysButton;
    private JButton themeToggleButton;
    
    // Theme management
    private boolean isDarkTheme = false;
    
    // Modern color scheme
    private static final Color PRIMARY_COLOR = new Color(79, 172, 254);
    private static final Color SUCCESS_COLOR = new Color(34, 197, 94);
    private static final Color DANGER_COLOR = new Color(239, 68, 68);
    private static final Color WARNING_COLOR = new Color(245, 158, 11);
    private static final Color SECONDARY_COLOR = new Color(107, 114, 128);

    public ServerAdminGUI() {
        dbManager = new DatabaseManager();
        setupModernLookAndFeel();
        initializeModernGUI();
        loadData();
    }

    private void setupModernLookAndFeel() {
        try {
            // Set FlatLaf Light theme as default
            FlatLightLaf.setup();
            
            // Customize FlatLaf properties for a more modern look
            UIManager.put("Button.arc", 8);
            UIManager.put("Component.arc", 8);
            UIManager.put("ProgressBar.arc", 8);
            UIManager.put("TextComponent.arc", 8);
            UIManager.put("ScrollBar.thumbArc", 8);
            UIManager.put("ScrollBar.thumbInsets", new Insets(2, 2, 2, 2));
            UIManager.put("Table.showHorizontalLines", true);
            UIManager.put("Table.showVerticalLines", false);
            UIManager.put("Table.intercellSpacing", new Dimension(0, 1));
            UIManager.put("TableHeader.height", 32);
            
        } catch (Exception e) {
            e.printStackTrace();
            // Fallback to system look and feel
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void initializeModernGUI() {
        setTitle("Bảng Điều Khiển Quản Trị Server - Hệ Thống Quản Lý Khóa");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 900);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(1200, 700));

        // Create main layout
        setLayout(new BorderLayout());
        
        // Add header panel
        add(createHeaderPanel(), BorderLayout.NORTH);
        
        // Create main panel with tabs
        JTabbedPane tabbedPane = createModernTabbedPane();
        add(tabbedPane, BorderLayout.CENTER);
        
        // Add status bar
        add(createStatusBar(), BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(16, 20, 16, 20));
        
        // Title section
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        titlePanel.setOpaque(false);
        
        JLabel titleLabel = new JLabel("Bảng Điều Khiển Quản Trị Server");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        
        JLabel subtitleLabel = new JLabel("Hệ Thống Quản Lý Khóa");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(new Color(255, 255, 255, 180));
        
        titlePanel.add(titleLabel);
        
        JPanel titleContainer = new JPanel();
        titleContainer.setLayout(new BoxLayout(titleContainer, BoxLayout.Y_AXIS));
        titleContainer.setOpaque(false);
        titleContainer.add(titleLabel);
        titleContainer.add(Box.createVerticalStrut(4));
        titleContainer.add(subtitleLabel);
        
        // Control section
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        controlPanel.setOpaque(false);
        
        themeToggleButton = createModernButton("Chế Độ Tối", SECONDARY_COLOR, 12);
        themeToggleButton.addActionListener(e -> toggleTheme());
        
        JButton refreshAllButton = createModernButton("Làm Mới Tất Cả", SUCCESS_COLOR, 12);
        refreshAllButton.addActionListener(e -> loadData());
        
        controlPanel.add(themeToggleButton);
        controlPanel.add(Box.createHorizontalStrut(8));
        controlPanel.add(refreshAllButton);
        
        headerPanel.add(titleContainer, BorderLayout.WEST);
        headerPanel.add(controlPanel, BorderLayout.EAST);
        
        return headerPanel;
    }

    private JTabbedPane createModernTabbedPane() {
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        // Users tab
        JPanel usersPanel = createModernUsersPanel();
        tabbedPane.addTab("Người Dùng", usersPanel);
        
        // Keys tab
        JPanel keysPanel = createModernKeysPanel();
        tabbedPane.addTab("Khóa", keysPanel);
        
        // Chat History tab
        JPanel chatPanel = createModernChatHistoryPanel();
        tabbedPane.addTab("Lịch Sử Trò Chuyện", chatPanel);
        
        // Logs tab
        JPanel logsPanel = createModernLogsPanel();
        tabbedPane.addTab("Nhật Ký Hệ Thống", logsPanel);

        return tabbedPane;
    }

    private JPanel createModernUsersPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 16));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Header section
        JPanel headerSection = createSectionHeader("Quản Lý Người Dùng", "Quản lý tài khoản người dùng đã đăng ký");
        panel.add(headerSection, BorderLayout.NORTH);

        // Table section
        String[] userColumns = {"ID", "Tên Người Dùng", "Mã Băm Mật Khẩu", "Ngày Tạo"};
        usersModel = new DefaultTableModel(userColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        usersTable = createModernTable(usersModel);
        JScrollPane usersScrollPane = new JScrollPane(usersTable);
        usersScrollPane.setBorder(BorderFactory.createEmptyBorder());
        panel.add(usersScrollPane, BorderLayout.CENTER);

        // Actions section
        JPanel actionsPanel = createActionsPanel();
        refreshButton = createModernButton("Làm Mới", SUCCESS_COLOR, 14);
        deleteUserButton = createModernButton("Xóa Người Dùng", DANGER_COLOR, 14);
        
        refreshButton.addActionListener(e -> loadUsersData());
        deleteUserButton.addActionListener(e -> deleteSelectedUser());
        
        actionsPanel.add(refreshButton);
        actionsPanel.add(Box.createHorizontalStrut(12));
        actionsPanel.add(deleteUserButton);
        panel.add(actionsPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createModernKeysPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 16));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Header section
        JPanel headerSection = createSectionHeader("Quản Lý Khóa", "Quản lý khóa mã hóa và chứng chỉ của khách hàng");
        panel.add(headerSection, BorderLayout.NORTH);

        // Table section
        String[] keyColumns = {"ID Khóa", "ID Người Dùng", "Tên Người Dùng", "Khóa Công Khai", "Khóa AES", "AES IV", "Ngày Tạo"};
        keysModel = new DefaultTableModel(keyColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        keysTable = createModernTable(keysModel);
        JScrollPane keysScrollPane = new JScrollPane(keysTable);
        keysScrollPane.setBorder(BorderFactory.createEmptyBorder());
        panel.add(keysScrollPane, BorderLayout.CENTER);

        // Actions section
        JPanel actionsPanel = createActionsPanel();
        JButton refreshKeysButton = createModernButton("Làm Mới", SUCCESS_COLOR, 14);
        deleteKeyButton = createModernButton("Xóa Khóa", DANGER_COLOR, 14);
        exportKeysButton = createModernButton("Xuất Khóa", PRIMARY_COLOR, 14);
        
        refreshKeysButton.addActionListener(e -> loadKeysData());
        deleteKeyButton.addActionListener(e -> deleteSelectedKey());
        exportKeysButton.addActionListener(e -> exportKeys());
        
        actionsPanel.add(refreshKeysButton);
        actionsPanel.add(Box.createHorizontalStrut(12));
        actionsPanel.add(deleteKeyButton);
        actionsPanel.add(Box.createHorizontalStrut(12));
        actionsPanel.add(exportKeysButton);
        panel.add(actionsPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createModernChatHistoryPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 16));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Header section
        JPanel headerSection = createSectionHeader("Lịch Sử Trò Chuyện", "Xem và quản lý lịch sử tin nhắn trò chuyện");
        panel.add(headerSection, BorderLayout.NORTH);

        // Table section
        String[] chatColumns = {"ID Trò Chuyện", "ID Người Dùng", "Tên Người Dùng", "Tin Nhắn", "Đã Mã Hóa", "Chữ Ký", "Đã Xác Thực", "Thời Gian"};
        chatHistoryModel = new DefaultTableModel(chatColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        chatHistoryTable = createModernTable(chatHistoryModel);
        JScrollPane chatScrollPane = new JScrollPane(chatHistoryTable);
        chatScrollPane.setBorder(BorderFactory.createEmptyBorder());
        panel.add(chatScrollPane, BorderLayout.CENTER);

        // Actions section
        JPanel actionsPanel = createActionsPanel();
        JButton refreshChatButton = createModernButton("Làm Mới", SUCCESS_COLOR, 14);
        clearChatButton = createModernButton("Xóa Lịch Sử", DANGER_COLOR, 14);
        
        refreshChatButton.addActionListener(e -> loadChatHistoryData());
        clearChatButton.addActionListener(e -> clearChatHistory());
        
        actionsPanel.add(refreshChatButton);
        actionsPanel.add(Box.createHorizontalStrut(12));
        actionsPanel.add(clearChatButton);
        panel.add(actionsPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createModernLogsPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 16));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Header section
        JPanel headerSection = createSectionHeader("Nhật Ký Hệ Thống", "Giám sát hoạt động và sự kiện hệ thống");
        panel.add(headerSection, BorderLayout.NORTH);

        // Log area
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font("JetBrains Mono", Font.PLAIN, 12));
        logArea.setMargin(new Insets(12, 12, 12, 12));

        JScrollPane logScrollPane = new JScrollPane(logArea);
        logScrollPane.setBorder(BorderFactory.createEmptyBorder());
        panel.add(logScrollPane, BorderLayout.CENTER);

        // Actions section
        JPanel actionsPanel = createActionsPanel();
        JButton clearLogsButton = createModernButton("Xóa Nhật Ký", DANGER_COLOR, 14);
        JButton exportLogsButton = createModernButton("Xuất Nhật Ký", PRIMARY_COLOR, 14);
        
        clearLogsButton.addActionListener(e -> logArea.setText(""));
        exportLogsButton.addActionListener(e -> exportLogs());
        
        actionsPanel.add(clearLogsButton);
        actionsPanel.add(Box.createHorizontalStrut(12));
        actionsPanel.add(exportLogsButton);
        panel.add(actionsPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createSectionHeader(String title, String description) {
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        
        JLabel descLabel = new JLabel(description);
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        descLabel.setForeground(SECONDARY_COLOR);
        descLabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        
        headerPanel.add(titleLabel);
        headerPanel.add(Box.createVerticalStrut(4));
        headerPanel.add(descLabel);
        
        return headerPanel;
    }

    private JPanel createActionsPanel() {
        JPanel actionsPanel = new JPanel();
        actionsPanel.setLayout(new BoxLayout(actionsPanel, BoxLayout.X_AXIS));
        actionsPanel.add(Box.createHorizontalGlue());
        return actionsPanel;
    }

    private JTable createModernTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowHeight(40);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        
        // Modern table header
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 40));
        
        // Center align cell content
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        return table;
    }

    private JButton createModernButton(String text, Color backgroundColor, int fontSize) {
        JButton button = new JButton(text);
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, fontSize));
        button.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add modern hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            Color originalColor = backgroundColor;
            
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(originalColor.darker());
            }
            
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(originalColor);
            }
        });
        
        return button;
    }

    private JPanel createStatusBar() {
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBorder(new EmptyBorder(8, 20, 8, 20));
        
        JLabel statusLabel = new JLabel("Sẵn Sàng");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(SECONDARY_COLOR);
        
        JLabel versionLabel = new JLabel("v2.0.0");
        versionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        versionLabel.setForeground(SECONDARY_COLOR);
        
        statusBar.add(statusLabel, BorderLayout.WEST);
        statusBar.add(versionLabel, BorderLayout.EAST);
        
        return statusBar;
    }

    private void toggleTheme() {
        try {
            if (isDarkTheme) {
                FlatLightLaf.setup();
                themeToggleButton.setText("Chế Độ Tối");
                isDarkTheme = false;
            } else {
                FlatDarkLaf.setup();
                themeToggleButton.setText("Chế Độ Sáng");
                isDarkTheme = true;
            }
            SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception e) {
            logMessage("Lỗi khi thay đổi chủ đề: " + e.getMessage());
        }
    }

    // Các phương thức tải dữ liệu và thao tác
    private void loadData() {
        loadUsersData();
        loadKeysData();
        loadChatHistoryData();
        logMessage("Dữ liệu đã được làm mới thành công");
    }

    private void loadUsersData() {
        usersModel.setRowCount(0);
        try (Connection conn = dbManager.getConnection()) {
            String sql = "SELECT user_id, username, password_hash, created_at FROM users ORDER BY created_at DESC";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("user_id"));
                row.add(rs.getString("username"));
                row.add(rs.getString("password_hash").substring(0, Math.min(20, rs.getString("password_hash").length())) + "...");
                row.add(rs.getTimestamp("created_at"));
                usersModel.addRow(row);
            }
            logMessage("Đã tải " + usersModel.getRowCount() + " người dùng");
        } catch (SQLException e) {
            logMessage("Lỗi khi tải dữ liệu người dùng: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadKeysData() {
        keysModel.setRowCount(0);
        try (Connection conn = dbManager.getConnection()) {
            String sql = "SELECT ck.key_id, ck.user_id, u.username, ck.public_key, ck.aes_key, ck.aes_iv, ck.created_at " +
                        "FROM client_keys ck " +
                        "LEFT JOIN users u ON ck.user_id = u.user_id " +
                        "ORDER BY ck.created_at DESC";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("key_id"));
                row.add(rs.getInt("user_id"));
                row.add(rs.getString("username"));
                
                String publicKey = rs.getString("public_key");
                row.add(publicKey != null ? publicKey.substring(0, Math.min(30, publicKey.length())) + "..." : "N/A");
                
                String aesKey = rs.getString("aes_key");
                row.add(aesKey != null ? aesKey.substring(0, Math.min(30, aesKey.length())) + "..." : "N/A");
                
                String aesIv = rs.getString("aes_iv");
                row.add(aesIv != null ? aesIv.substring(0, Math.min(30, aesIv.length())) + "..." : "N/A");
                
                row.add(rs.getTimestamp("created_at"));
                keysModel.addRow(row);
            }
            logMessage("Đã tải " + keysModel.getRowCount() + " khóa");
        } catch (SQLException e) {
            logMessage("Lỗi khi tải dữ liệu khóa: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadChatHistoryData() {
        chatHistoryModel.setRowCount(0);
        try (Connection conn = dbManager.getConnection()) {
            String sql = "SELECT ch.chat_id, ch.user_id, u.username, ch.raw_message, ch.encrypted_message, " +
                        "ch.signature, ch.verified, ch.timestamp " +
                        "FROM chat_history ch " +
                        "LEFT JOIN users u ON ch.user_id = u.user_id " +
                        "ORDER BY ch.timestamp DESC LIMIT 100";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("chat_id"));
                row.add(rs.getInt("user_id"));
                row.add(rs.getString("username"));
                row.add(rs.getString("raw_message"));
                
                String encryptedMessage = rs.getString("encrypted_message");
                row.add(encryptedMessage != null ? encryptedMessage.substring(0, Math.min(30, encryptedMessage.length())) + "..." : "N/A");
                
                String signature = rs.getString("signature");
                row.add(signature != null ? signature.substring(0, Math.min(30, signature.length())) + "..." : "N/A");
                
                row.add(rs.getBoolean("verified") ? "Có" : "Không");
                row.add(rs.getTimestamp("timestamp"));
                chatHistoryModel.addRow(row);
            }
            logMessage("Đã tải " + chatHistoryModel.getRowCount() + " tin nhắn trò chuyện");
        } catch (SQLException e) {
            logMessage("Lỗi khi tải dữ liệu lịch sử trò chuyện: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void deleteSelectedUser() {
        int selectedRow = usersTable.getSelectedRow();
        if (selectedRow == -1) {
            showModernDialog("Vui lòng chọn một người dùng để xóa.", "Không Có Lựa Chọn", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int userId = (Integer) usersModel.getValueAt(selectedRow, 0);
        String username = (String) usersModel.getValueAt(selectedRow, 1);

        int confirm = showModernConfirmDialog(
            "Bạn có chắc chắn muốn xóa người dùng '" + username + "'?\nViệc này cũng sẽ xóa tất cả khóa và lịch sử trò chuyện liên quan.", 
            "Xác Nhận Xóa");

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = dbManager.getConnection()) {
                conn.setAutoCommit(false);
                
                PreparedStatement stmt1 = conn.prepareStatement("DELETE FROM chat_history WHERE user_id = ?");
                stmt1.setInt(1, userId);
                stmt1.executeUpdate();
                
                PreparedStatement stmt2 = conn.prepareStatement("DELETE FROM client_keys WHERE user_id = ?");
                stmt2.setInt(1, userId);
                stmt2.executeUpdate();
                
                PreparedStatement stmt3 = conn.prepareStatement("DELETE FROM users WHERE user_id = ?");
                stmt3.setInt(1, userId);
                stmt3.executeUpdate();
                
                conn.commit();
                loadData();
                logMessage("Người dùng '" + username + "' đã được xóa thành công");
                
            } catch (SQLException e) {
                logMessage("Lỗi khi xóa người dùng: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void deleteSelectedKey() {
        int selectedRow = keysTable.getSelectedRow();
        if (selectedRow == -1) {
            showModernDialog("Vui lòng chọn một khóa để xóa.", "Không Có Lựa Chọn", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int keyId = (Integer) keysModel.getValueAt(selectedRow, 0);
        String username = (String) keysModel.getValueAt(selectedRow, 2);

        int confirm = showModernConfirmDialog(
            "Bạn có chắc chắn muốn xóa khóa của người dùng '" + username + "'?", 
            "Xác Nhận Xóa");

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = dbManager.getConnection()) {
                PreparedStatement stmt = conn.prepareStatement("DELETE FROM client_keys WHERE key_id = ?");
                stmt.setInt(1, keyId);
                stmt.executeUpdate();
                
                loadKeysData();
                logMessage("Khóa của người dùng '" + username + "' đã được xóa thành công");
                
            } catch (SQLException e) {
                logMessage("Lỗi khi xóa khóa: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void clearChatHistory() {
        int confirm = showModernConfirmDialog(
            "Bạn có chắc chắn muốn xóa tất cả lịch sử trò chuyện?", 
            "Xác Nhận Xóa");

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = dbManager.getConnection()) {
                PreparedStatement stmt = conn.prepareStatement("DELETE FROM chat_history");
                stmt.executeUpdate();
                
                loadChatHistoryData();
                logMessage("Lịch sử trò chuyện đã được xóa thành công");
                
            } catch (SQLException e) {
                logMessage("Lỗi khi xóa lịch sử trò chuyện: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void exportKeys() {
    JFileChooser chooser = new JFileChooser();
    chooser.setDialogTitle("Xuất khóa ra JSON");
    chooser.setSelectedFile(new java.io.File("khoa_xuat.json"));
    if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
        try {
            java.io.File file = chooser.getSelectedFile();
            exportKeysToFile(file.getAbsolutePath());
            logMessage("Khóa đã được xuất tới: " + file.getAbsolutePath());
            showModernDialog("Xuất khóa thành công!", "Hoàn thành", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            logMessage("Lỗi xuất khóa: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

// Giữ nguyên tên exportLogs(), chỉ đổi nội dung bên trong:
private void exportLogs() {
    JFileChooser chooser = new JFileChooser();
    chooser.setDialogTitle("Xuất nhật ký ra tệp văn bản");
    chooser.setSelectedFile(new java.io.File("nhat_ky.txt"));
    if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
        try {
            java.io.File file = chooser.getSelectedFile();
            java.nio.file.Files.write(file.toPath(), logArea.getText().getBytes());
            logMessage("Nhật ký đã được xuất tới: " + file.getAbsolutePath());
            showModernDialog("Xuất nhật ký thành công!", "Hoàn thành", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            logMessage("Lỗi xuất nhật ký: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

private void exportKeysToFile(String filePath) throws Exception {
    ObjectMapper mapper = new ObjectMapper();
    java.util.List<java.util.Map<String, Object>> keysList = new java.util.ArrayList<>();
    try (Connection conn = dbManager.getConnection()) {
        String sql = 
            "SELECT ck.key_id, ck.user_id, u.username, ck.public_key, ck.aes_key, ck.aes_iv, ck.created_at " +
            "FROM client_keys ck " +
            "LEFT JOIN users u ON ck.user_id = u.user_id " +
            "ORDER BY ck.created_at DESC";
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            java.util.Map<String, Object> keyData = new java.util.HashMap<>();
            keyData.put("key_id", rs.getInt("key_id"));
            keyData.put("user_id", rs.getInt("user_id"));
            keyData.put("username", rs.getString("username"));
            keyData.put("public_key", rs.getString("public_key"));
            keyData.put("aes_key", rs.getString("aes_key"));
            keyData.put("aes_iv", rs.getString("aes_iv"));
            keyData.put("created_at", rs.getTimestamp("created_at").toString());
            keysList.add(keyData);
        }
    }
    mapper.writerWithDefaultPrettyPrinter()
          .writeValue(new java.io.File(filePath), keysList);
}

private void showModernDialog(String message, String title, int messageType) {
    JOptionPane.showMessageDialog(this, message, title, messageType);
}

private int showModernConfirmDialog(String message, String title) {
    return JOptionPane.showConfirmDialog(this,
        message, title, JOptionPane.YES_NO_OPTION);
}
    private void logMessage(String message) {
        String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
        logArea.append("[" + timestamp + "] " + message + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        
        SwingUtilities.invokeLater(() -> {
            new ServerAdminGUI().setVisible(true);
        });
    }
}

