package com.example.database;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Base64;

public class DatabaseManager {
    private static final String JDBC_URL = "jdbc:mysql://mysql.freehostia.com:3306/thatat0_key";
    private static final String USERNAME = "thatat0_key";
    private static final String PASSWORD = "Thang@12";

    private Connection connection;

    public DatabaseManager() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
        }
        return connection;
    }

    // Hash password using SHA-256
    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedBytes = md.digest(password.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : hashedBytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    // Register new user
    public boolean registerUser(String username, String password) {
        try {
            String hashedPassword = hashPassword(password);
            String sql = "INSERT INTO users (username, password_hash) VALUES (?, ?)";
            
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, hashedPassword);
                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            return false; // Username already exists
        } catch (SQLException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Login user
    public int loginUser(String username, String password) {
        try {
            String hashedPassword = hashPassword(password);
            String sql = "SELECT user_id FROM users WHERE username = ? AND password_hash = ?";
            
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, hashedPassword);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    return rs.getInt("user_id");
                }
                return -1; // Login failed
            }
        } catch (SQLException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            return -1;
        }
    }

    public void saveClientKeys(int userId, String aesKey, String aesIV) {
    try {
        // Bây giờ chúng ta không cần lưu public key nữa, chỉ cần lưu aes_key và aes_iv
        String publicKeyPlaceholder = "decoded_on_server"; 
        
        String sql = "INSERT INTO client_keys (user_id, public_key, aes_key, aes_iv) VALUES (?, ?, ?, ?) " +
                    "ON DUPLICATE KEY UPDATE public_key = VALUES(public_key), aes_key = VALUES(aes_key), aes_iv = VALUES(aes_iv)";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setString(2, publicKeyPlaceholder); // <-- Không đọc từ file nữa
            stmt.setString(3, aesKey);
            stmt.setString(4, aesIV);
            stmt.executeUpdate();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    // Save client keys with byte arrays
    public void saveClientKeys(int userId, byte[] aesKey, byte[] aesIV) {
        String aesKeyBase64 = Base64.getEncoder().encodeToString(aesKey);
        String aesIVBase64 = Base64.getEncoder().encodeToString(aesIV);
        saveClientKeys(userId, aesKeyBase64, aesIVBase64);
    }
    // Get client keys
    public ClientKeys getClientKeys(int userId) {
        try {
            String sql = "SELECT public_key, aes_key, aes_iv FROM client_keys WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
            
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, userId);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    return new ClientKeys(
                        rs.getString("public_key"),
                        rs.getString("aes_key"), 
                        rs.getString("aes_iv")
                    );
                }
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Save chat history with verification status
    public void saveChatHistory(int userId, String rawMessage, String encryptedMessage, String signature, boolean verified) {
        try {
            String sql = "INSERT INTO chat_history (user_id, raw_message, encrypted_message, signature, verified) VALUES (?, ?, ?, ?, ?)";
            
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, userId);
                stmt.setString(2, rawMessage);
                stmt.setString(3, encryptedMessage);
                stmt.setString(4, signature);
                stmt.setBoolean(5, verified);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Save chat history (legacy method for backward compatibility)
    public void saveChatHistory(int userId, String messageType, String messageContent) {
        saveChatHistory(userId, messageContent, "", "", true);
    }

    // Close connection
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Inner class for client keys
    public static class ClientKeys {
        private String publicKey;
        private String aesKey;
        private String aesIV;

        public ClientKeys(String publicKey, String aesKey, String aesIV) {
            this.publicKey = publicKey;
            this.aesKey = aesKey;
            this.aesIV = aesIV;
        }

        public String getPublicKey() {
            return publicKey;
        }

        public String getAesKey() {
            return aesKey;
        }

        public String getAesIV() {
            return aesIV;
        }
    }
}


