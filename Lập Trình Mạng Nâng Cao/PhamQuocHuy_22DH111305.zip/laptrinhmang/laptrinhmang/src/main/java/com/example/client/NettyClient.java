// File: com/example/client/NettyClient.java

package com.example.client;

import java.io.FileInputStream; // <-- THÊM MỚI
import java.security.KeyStore; // <-- THÊM MỚI

import javax.net.ssl.TrustManagerFactory;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel; // <-- THÊM MỚI
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.util.CharsetUtil;

public class NettyClient {
    private final String host;
    private final int port;
    private Channel channel;
    private EventLoopGroup group;
    private ClientHandler clientHandler;
    private SslContext sslContext; // <-- THÊM MỚI

    public NettyClient(String host, int port) {
        this.host = host;
        this.port = port;
        this.clientHandler = new ClientHandler();
        
        // --- BẮT ĐẦU PHẦN THÊM MỚI CHO SSL ---
        try {
            // Client cần tin tưởng chứng chỉ của server.
            // Chúng ta tải keystore của server và dùng nó như một truststore.
            char[] password = "netty123".toCharArray();
            KeyStore trustStore = KeyStore.getInstance("JKS");
            trustStore.load(new FileInputStream("D:\\hk he nam 3\\LTMNC\\laptrinhmang\\laptrinhmang\\src\\main\\java\\com\\example\\server\\server.keystore"), password);

            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init(trustStore);
            
            this.sslContext = SslContextBuilder.forClient()
                .trustManager(trustManagerFactory)
                .build();
            System.out.println("Đã nạp SSL Context cho Client thành công.");
        } catch (Exception e) {
            System.err.println("Lỗi khi tạo SSL Context cho Client:");
            e.printStackTrace();
            this.sslContext = null;
        }
        // --- KẾT THÚC PHẦN THÊM MỚI CHO SSL ---
    }
    
    // Method to set the GUI reference
    public void setClientGUI(ClientGUI clientGUI) {
        this.clientHandler.setClientGUI(clientGUI);
    }

    public void connect() throws Exception {
        if (sslContext == null) {
            throw new IllegalStateException("Không thể kết nối vì SSL Context bị lỗi.");
        }
        group = new NioEventLoopGroup();
        
        try {
            Bootstrap bootstrap = new Bootstrap();
            bootstrap.group(group)
                    .channel(NioSocketChannel.class)
                    .handler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel ch) throws Exception {
                            ChannelPipeline pipeline = ch.pipeline();

                            // <-- SỬA ĐỔI: Thêm SslHandler vào ĐẦU TIÊN trong pipeline
                            pipeline.addLast(sslContext.newHandler(ch.alloc(), host, port));
                            
                            // Các handler khác giữ nguyên và đặt SAU SslHandler
                            pipeline.addLast(new StringDecoder(CharsetUtil.UTF_8));
                            pipeline.addLast(new StringEncoder(CharsetUtil.UTF_8));
                        
                            pipeline.addLast(clientHandler);
                        }
                    });

            ChannelFuture future = bootstrap.connect(host, port).sync();
            channel = future.channel();
            System.out.println("Connected to server: " + host + ":" + port + " with SSL/TLS enabled."); // <-- SỬA ĐỔI
        } catch (Exception e) {
            group.shutdownGracefully();
            throw e;
        }
    }

    public void sendMessage(String message) {
        if (channel != null && channel.isActive()) {
            channel.writeAndFlush(message);
        }
    }

    public void disconnect() {
        if (channel != null) {
            channel.close();
        }
        if (group != null) {
            group.shutdownGracefully();
        }
    }

    public boolean isConnected() {
        return channel != null && channel.isActive();
    }
}




