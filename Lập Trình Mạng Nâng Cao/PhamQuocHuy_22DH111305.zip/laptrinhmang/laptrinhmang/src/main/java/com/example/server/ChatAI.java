package com.example.server;

import com.google.genai.Client;
import com.google.genai.types.Content;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;
import com.google.genai.types.Part;

public class ChatAI {
    private static final String MODEL_NAME = "gemini-2.5-flash";
    private final Client client;
    private final GenerateContentConfig config;

    public ChatAI() {
        String apiKey = "AIzaSyCTanHHCtufZsx5liqVwiohdCTXjsilims";
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException("LỖI: GEMINI_API_KEY chưa được thiết lập.");
        }

        // Khởi tạo client (mặc định sẽ dùng Gemini API và đọc API key từ biến môi trường)
        this.client = Client.builder()
            .apiKey(apiKey)
            .build();

        // Tạo config với hệ thống instruction
        this.config = GenerateContentConfig.builder()
            .temperature(0.7f)
            .systemInstruction(
                Content.fromParts(
                    Part.fromText("Bạn là một trợ lý AI thông minh và hữu ích. Hãy trả lời câu hỏi của người dùng một cách súc tích và chính xác.")
                )
            )
            .build();
    }

    /**
     * Gửi prompt đến Gemini và trả về toàn bộ phản hồi.
     */
    public String generateContent(String userPrompt) {
        try {
            // Gọi thẳng API generateContent
            GenerateContentResponse response = client.models.generateContent(
                MODEL_NAME,
                userPrompt,
                config
            );
            return response.text();
        } catch (Exception e) {
            e.printStackTrace();
            return "Xin lỗi, tôi đang gặp sự cố. Vui lòng thử lại sau.";
        }
    }
}
