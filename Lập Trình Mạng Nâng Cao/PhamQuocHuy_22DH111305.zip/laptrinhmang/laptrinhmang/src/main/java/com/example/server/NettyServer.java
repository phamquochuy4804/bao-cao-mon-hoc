package com.example.server;

import java.io.FileInputStream; // <-- THÊM MỚI
import java.security.KeyStore; // <-- THÊM MỚI
import java.security.PrivateKey;

import javax.net.ssl.KeyManagerFactory; // <-- THÊM MỚI

import com.example.utils.RSAUtils;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.util.CharsetUtil; // <-- THÊM MỚI

public class NettyServer {
    private final int port;
    private PrivateKey serverPrivateKey;
    private final SslContext sslContext; // <-- THÊM MỚI

    public NettyServer(int port) throws Exception { // <-- SỬA ĐỔI: Thêm throws Exception
        this.port = port;
        loadServerPrivateKey();

        // --- BẮT ĐẦU PHẦN THÊM MỚI CHO SSL ---
        char[] password = "netty123".toCharArray(); // Mật khẩu bạn đã đặt ở Bước 1
        KeyStore keyStore = KeyStore.getInstance("JKS");
        keyStore.load(new FileInputStream("D:\\hk he nam 3\\LTMNC\\laptrinhmang\\laptrinhmang\\src\\main\\java\\com\\example\\server\\server.keystore"), password); // Tải keystore

        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyManagerFactory.init(keyStore, password);

        this.sslContext = SslContextBuilder.forServer(keyManagerFactory).build();
        System.out.println("Đã nạp SSL Context cho Server thành công.");
        // --- KẾT THÚC PHẦN THÊM MỚI CHO SSL ---
    }

    private void loadServerPrivateKey() {
        try {
            // File này phải nằm ở thư mục gốc của project Server
            this.serverPrivateKey = RSAUtils.readPrivateKeyFromFile("D:\\hk he nam 3\\LTMNC\\laptrinhmang\\laptrinhmang\\src\\main\\java\\com\\example\\client\\private.key");
            System.out.println("Đã nạp Private Key của Server thành công.");
        } catch (Exception e) {
            System.err.println("LỖI NGHIÊM TRỌNG: Không thể nạp Private Key của Server. Server không thể khởi động.");
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void start() throws Exception {
        EventLoopGroup bossGroup = new NioEventLoopGroup(1);
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
            ServerBootstrap bootstrap = new ServerBootstrap();
            bootstrap.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel ch) throws Exception {
                            ChannelPipeline pipeline = ch.pipeline();

                            // <-- SỬA ĐỔI: Thêm SslHandler vào ĐẦU TIÊN trong pipeline
                            pipeline.addLast(sslContext.newHandler(ch.alloc()));

                            // Các handler khác giữ nguyên và đặt SAU SslHandler
                            pipeline.addLast(new StringDecoder(CharsetUtil.UTF_8));
                            pipeline.addLast(new StringEncoder(CharsetUtil.UTF_8));
                            pipeline.addLast(new ServerHandler(serverPrivateKey));
                        }
                    })
                    .option(ChannelOption.SO_BACKLOG, 128)
                    .childOption(ChannelOption.SO_KEEPALIVE, true);

            ChannelFuture future = bootstrap.bind(port).sync();
            System.out.println("Server started on port " + port + " with SSL/TLS enabled."); // <-- SỬA ĐỔI
            future.channel().closeFuture().sync();
        } finally {
            workerGroup.shutdownGracefully();
            bossGroup.shutdownGracefully();
        }
    }

    public static void main(String[] args) throws Exception {
        new NettyServer(8080).start();
    }
}