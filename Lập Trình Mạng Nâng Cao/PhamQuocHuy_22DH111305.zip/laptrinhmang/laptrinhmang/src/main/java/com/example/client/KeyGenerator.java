package com.example.client;

import java.io.FileOutputStream;
import java.security.KeyPair;

import com.example.utils.RSAUtils;

public class KeyGenerator {
    public static void main(String[] args) throws Exception {
        // Tạo cặp khóa cho Server
        KeyPair serverKeyPair = RSAUtils.generateKeyPair();

        // Lưu Public Key của Server
        try (FileOutputStream fos = new FileOutputStream("server_public.key")) {
            fos.write(serverKeyPair.getPublic().getEncoded());
        }

        // Lưu Private Key của Server
        try (FileOutputStream fos = new FileOutputStream("server_private.key")) {
            fos.write(serverKeyPair.getPrivate().getEncoded());
        }

        System.out.println("Đã tạo thành công 'server_public.key' và 'server_private.key'.");
        System.out.println("Hãy copy 'server_public.key' vào thư mục của Client.");
        System.out.println("Giữ 'server_private.key' ở thư mục của Server.");
    }
}