package com.example.client;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import java.nio.file.Files; // và các import khác của AWT/Swing
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.SecretKey;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton; // <-- Import cần thiết
import javax.swing.JFileChooser; // <-- Import cần thiết
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import com.example.utils.AESUtils;
import com.example.utils.RSAUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;

public class ClientGUI extends JFrame {
    private NettyClient client;
    private ObjectMapper objectMapper = new ObjectMapper();
    private int currentUserId = -1;
    private PrivateKey clientPrivateKey = null;
    private PublicKey clientPublicKey = null;
    private PublicKey serverPublicKey = null;
    // UI Components
    private JPanel mainPanel;
    private JPanel loginPanel;
    private JPanel chatPanel;
    
    // Login components
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private JButton themeToggleButton;
    
    // Chat components
    private JTextArea chatArea;
    private JTextField messageField;
    private JButton sendButton;
    private JButton disconnectButton;
    private JLabel statusLabel;
    private JLabel connectionStatusLabel;

    // <-- THÊM MỚI: Các thành phần UI cho việc quản lý khóa
    private JButton generateKeysButton;
    private JButton importPrivateKeyButton;
    private JButton importPublicKeyButton;
    private JLabel privateKeyStatusLabel;
    private JLabel publicKeyStatusLabel;
    
    // Theme management
    private boolean isDarkTheme = false;
    
    // Modern color scheme
    private static final Color PRIMARY_COLOR = new Color(79, 172, 254);
    private static final Color SUCCESS_COLOR = new Color(34, 197, 94);
    private static final Color DANGER_COLOR = new Color(239, 68, 68);
    private static final Color WARNING_COLOR = new Color(245, 158, 11);
    private static final Color SECONDARY_COLOR = new Color(107, 114, 128);

    public ClientGUI() {
        setupModernLookAndFeel();
        initializeModernGUI();
         client = new NettyClient("localhost", 8080);
        client.setClientGUI(this);
        loadServerPublicKey();
    }

    private void setupModernLookAndFeel() {
        try {
            FlatLightLaf.setup();
            UIManager.put("Button.arc", 12);
            UIManager.put("Component.arc", 12);
            UIManager.put("ProgressBar.arc", 12);
            UIManager.put("TextComponent.arc", 12);
            UIManager.put("ScrollBar.thumbArc", 12);
            UIManager.put("ScrollBar.thumbInsets", new Insets(2, 2, 2, 2));
            UIManager.put("TabbedPane.tabArc", 12);
            UIManager.put("TabbedPane.cardArc", 12);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void initializeModernGUI() {
        setTitle("Hệ thống Chat Client-Server");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(800, 600));

        mainPanel = new JPanel(new CardLayout());
        
        createModernLoginPanel();
        createModernChatPanel();
        
        mainPanel.add(loginPanel, "LOGIN");
        mainPanel.add(chatPanel, "CHAT");
        
        add(mainPanel);
        
        CardLayout cl = (CardLayout) mainPanel.getLayout();
        cl.show(mainPanel, "LOGIN");
    }

    private void createModernLoginPanel() {
        loginPanel = new JPanel(new BorderLayout());
        JPanel headerPanel = createLoginHeader();
        loginPanel.add(headerPanel, BorderLayout.NORTH);
        JPanel formPanel = createLoginForm();
        loginPanel.add(formPanel, BorderLayout.CENTER);
        JPanel footerPanel = createLoginFooter();
        loginPanel.add(footerPanel, BorderLayout.SOUTH);
    }

    private JPanel createLoginHeader() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(20, 30, 20, 30));
        JPanel titleSection = new JPanel();
        titleSection.setLayout(new BoxLayout(titleSection, BoxLayout.Y_AXIS));
        titleSection.setOpaque(false);
        JLabel titleLabel = new JLabel("Hệ thống Client-Server");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        JLabel subtitleLabel = new JLabel("Nền tảng giao tiếp bảo mật");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtitleLabel.setForeground(new Color(255, 255, 255, 180));
        subtitleLabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        titleSection.add(titleLabel);
        titleSection.add(Box.createVerticalStrut(8));
        titleSection.add(subtitleLabel);
        themeToggleButton = createModernButton("Chế độ tối", SECONDARY_COLOR, 12);
        themeToggleButton.addActionListener(e -> toggleTheme());
        headerPanel.add(titleSection, BorderLayout.WEST);
        headerPanel.add(themeToggleButton, BorderLayout.EAST);
        return headerPanel;
    }

    private JPanel createLoginForm() {
        JPanel containerPanel = new JPanel(new GridBagLayout());
        containerPanel.setOpaque(false);
        JPanel cardPanel = new JPanel(new GridBagLayout());
        cardPanel.setOpaque(true);
        cardPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UIManager.getColor("Component.borderColor"), 1),
            new EmptyBorder(40, 40, 40, 40)
        ));
        cardPanel.setPreferredSize(new Dimension(600, 400));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 0, 12, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        JLabel formTitle = new JLabel("Chào mừng trở lại", SwingConstants.CENTER);
        formTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        formTitle.setForeground(UIManager.getColor("Label.foreground"));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        cardPanel.add(formTitle, gbc);
        JLabel formSubtitle = new JLabel("Đăng nhập vào tài khoản của bạn", SwingConstants.CENTER);
        formSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        formSubtitle.setForeground(UIManager.getColor("Label.disabledForeground"));
        gbc.gridy = 1;
        cardPanel.add(formSubtitle, gbc);
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.insets = new Insets(20, 0, 8, 0);
        JLabel usernameLabel = new JLabel("Tên đăng nhập");
        usernameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        usernameLabel.setForeground(UIManager.getColor("Label.foreground"));
        gbc.gridx = 0; gbc.gridwidth = 2;
        cardPanel.add(usernameLabel, gbc);
        usernameField = createModernTextField();
        usernameField.setPreferredSize(new Dimension(320, 44));
        usernameField.setMinimumSize(new Dimension(320, 44));
        gbc.gridy = 3;
        gbc.insets = new Insets(4, 0, 12, 0);
        cardPanel.add(usernameField, gbc);
        JLabel passwordLabel = new JLabel("Mật khẩu");
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        passwordLabel.setForeground(UIManager.getColor("Label.foreground"));
        gbc.gridy = 4;
        gbc.insets = new Insets(8, 0, 8, 0);
        cardPanel.add(passwordLabel, gbc);
        passwordField = createModernPasswordField();
        passwordField.setPreferredSize(new Dimension(320, 44));
        passwordField.setMinimumSize(new Dimension(320, 44));
        gbc.gridy = 5;
        gbc.insets = new Insets(4, 0, 20, 0);
        cardPanel.add(passwordField, gbc);
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setOpaque(false);
        GridBagConstraints buttonGbc = new GridBagConstraints();
        buttonGbc.insets = new Insets(0, 6, 0, 6);
        buttonGbc.fill = GridBagConstraints.HORIZONTAL;
        buttonGbc.weightx = 1.0;
        loginButton = createModernButton("Đăng nhập", PRIMARY_COLOR, 14);
        loginButton.setPreferredSize(new Dimension(140, 44));
        loginButton.setMinimumSize(new Dimension(140, 44));
        buttonGbc.gridx = 0;
        buttonPanel.add(loginButton, buttonGbc);
        registerButton = createModernButton("Đăng ký", SUCCESS_COLOR, 14);
        registerButton.setPreferredSize(new Dimension(140, 44));
        registerButton.setMinimumSize(new Dimension(140, 44));
        buttonGbc.gridx = 1;
        buttonPanel.add(registerButton, buttonGbc);
        gbc.gridy = 6;
        gbc.insets = new Insets(0, 0, 12, 0);
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        cardPanel.add(buttonPanel, gbc);
        statusLabel = new JLabel(" ", SwingConstants.CENTER);
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        statusLabel.setForeground(DANGER_COLOR);
        gbc.gridy = 7;
        gbc.insets = new Insets(8, 0, 0, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        cardPanel.add(statusLabel, gbc);
        loginButton.addActionListener(e -> handleLogin());
        registerButton.addActionListener(e -> handleRegister());
        passwordField.addActionListener(e -> handleLogin());
        GridBagConstraints containerGbc = new GridBagConstraints();
        containerGbc.weightx = 1.0;
        containerGbc.weighty = 1.0;
        containerGbc.fill = GridBagConstraints.NONE;
        containerGbc.anchor = GridBagConstraints.CENTER;
        containerPanel.add(cardPanel, containerGbc);
        return containerPanel;
    }

    private JPanel createLoginFooter() {
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footerPanel.setOpaque(false);
        footerPanel.setBorder(new EmptyBorder(20, 0, 20, 0));
        JLabel footerLabel = new JLabel("Được tạo bởi Modern Java Swing");
        footerLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        footerLabel.setForeground(UIManager.getColor("Label.disabledForeground"));
        footerPanel.add(footerLabel);
        return footerPanel;
    }

    private void createModernChatPanel() {
        chatPanel = new JPanel(new BorderLayout());
        JPanel headerPanel = createChatHeader();
        chatPanel.add(headerPanel, BorderLayout.NORTH);
        JPanel chatAreaPanel = createChatArea();
        chatPanel.add(chatAreaPanel, BorderLayout.CENTER);
        JPanel inputPanel = createMessageInput();
        chatPanel.add(inputPanel, BorderLayout.SOUTH);
    }

    private JPanel createChatHeader() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(16, 24, 16, 24));
        JPanel titleSection = new JPanel();
        titleSection.setLayout(new BoxLayout(titleSection, BoxLayout.Y_AXIS));
        titleSection.setOpaque(false);
        JLabel titleLabel = new JLabel("Giao diện trò chuyện");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        connectionStatusLabel = new JLabel("Đã kết nối");
        connectionStatusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        connectionStatusLabel.setForeground(new Color(255, 255, 255, 180));
        connectionStatusLabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        titleSection.add(titleLabel);
        titleSection.add(Box.createVerticalStrut(4));
        titleSection.add(connectionStatusLabel);
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        controlPanel.setOpaque(false);
        JButton themeButton = createModernButton("Chế độ tối", SECONDARY_COLOR, 12);
        themeButton.addActionListener(e -> toggleTheme());
        disconnectButton = createModernButton("Ngắt kết nối", DANGER_COLOR, 12);
        disconnectButton.addActionListener(e -> handleDisconnect());
        controlPanel.add(themeButton);
        controlPanel.add(disconnectButton);
        headerPanel.add(titleSection, BorderLayout.WEST);
        headerPanel.add(controlPanel, BorderLayout.EAST);
        return headerPanel;
    }

    private JPanel createChatArea() {
        JPanel containerPanel = new JPanel(new BorderLayout());
        containerPanel.setBorder(new EmptyBorder(20, 20, 0, 20));
        containerPanel.setOpaque(false);
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setFont(new Font("JetBrains Mono", Font.PLAIN, 13));
        chatArea.setOpaque(true);
        chatArea.setBorder(new EmptyBorder(16, 16, 16, 16));
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(chatArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UIManager.getColor("Component.borderColor"), 1),
            BorderFactory.createEmptyBorder()
        ));
        containerPanel.add(scrollPane, BorderLayout.CENTER);
        return containerPanel;
    }

    private JPanel createMessageInput() {
    JPanel containerPanel = new JPanel(new BorderLayout());
    containerPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
    containerPanel.setOpaque(false);

    // Panel chính chứa cả phần quản lý key và phần nhập tin nhắn
    JPanel mainCard = new JPanel();
    mainCard.setLayout(new BoxLayout(mainCard, BoxLayout.Y_AXIS));
    mainCard.setOpaque(true);
    mainCard.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createLineBorder(UIManager.getColor("Component.borderColor"), 1),
        new EmptyBorder(16, 16, 16, 16)
    ));

    // --- PHẦN QUẢN LÝ KHÓA (MỚI) ---
    JPanel keyManagementPanel = new JPanel(new GridBagLayout());
    keyManagementPanel.setOpaque(false);
    keyManagementPanel.setBorder(BorderFactory.createTitledBorder("Quản lý Khóa RSA"));
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);
    gbc.fill = GridBagConstraints.HORIZONTAL;

    // Nút tạo khóa
    generateKeysButton = new JButton("1. Tạo cặp khóa mới");
    gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
    keyManagementPanel.add(generateKeysButton, gbc);

    // Nút import private key
    importPrivateKeyButton = new JButton("2. Import Private Key");
    gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
    keyManagementPanel.add(importPrivateKeyButton, gbc);

    // Trạng thái private key
    privateKeyStatusLabel = new JLabel("Trạng thái: Chưa có khóa");
    gbc.gridx = 1; gbc.gridy = 1;
    keyManagementPanel.add(privateKeyStatusLabel, gbc);
    
    // Nút import public key
    importPublicKeyButton = new JButton("3. Import Public Key");
    gbc.gridx = 0; gbc.gridy = 2;
    keyManagementPanel.add(importPublicKeyButton, gbc);
    
    // Trạng thái public key
    publicKeyStatusLabel = new JLabel("Trạng thái: Chưa có khóa");
    gbc.gridx = 1; gbc.gridy = 2;
    keyManagementPanel.add(publicKeyStatusLabel, gbc);
    
    // --- PHẦN NHẬP TIN NHẮN (SỬA ĐỔI) ---
    JPanel messageInputPanel = new JPanel(new BorderLayout(12, 12));
    messageInputPanel.setOpaque(false);
    messageInputPanel.setBorder(BorderFactory.createTitledBorder("Gửi Tin Nhắn"));

    JLabel inputLabel = new JLabel("Nhập câu hỏi cho AI, hoặc URL (https://domain.com) để quét:");
    messageField = createModernTextField();
    messageField.setPreferredSize(new Dimension(0, 44));
    sendButton = createModernButton("Gửi Tin Nhắn (Bảo mật)", SUCCESS_COLOR, 14);
    sendButton.setPreferredSize(new Dimension(200, 44));
    
    messageInputPanel.add(inputLabel, BorderLayout.NORTH);
    messageInputPanel.add(messageField, BorderLayout.CENTER);
    messageInputPanel.add(sendButton, BorderLayout.EAST);

    // Thêm listener cho các nút
    addKeyManagementListeners();
    sendButton.addActionListener(e -> handleSendMessage());
    messageField.addActionListener(e -> handleSendMessage());

    // Thêm các panel con vào panel chính
    mainCard.add(keyManagementPanel);
    mainCard.add(Box.createVerticalStrut(15)); // Khoảng cách
    mainCard.add(messageInputPanel);

    containerPanel.add(mainCard, BorderLayout.CENTER);
    return containerPanel;
}

    private JTextField createModernTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UIManager.getColor("Component.borderColor"), 1),
            new EmptyBorder(12, 16, 12, 16)
        ));
        return field;
    }

    private JPasswordField createModernPasswordField() {
        JPasswordField field = new JPasswordField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UIManager.getColor("Component.borderColor"), 1),
            new EmptyBorder(12, 16, 12, 16)
        ));
        return field;
    }

    private JButton createModernButton(String text, Color backgroundColor, int fontSize) {
        JButton button = new JButton(text);
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, fontSize));
        button.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            Color originalColor = backgroundColor;
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(originalColor.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(originalColor);
            }
        });
        return button;
    }

    private void toggleTheme() {
        try {
            if (isDarkTheme) {
                FlatLightLaf.setup();
                themeToggleButton.setText("Chế độ tối");
                isDarkTheme = false;
            } else {
                FlatDarkLaf.setup();
                themeToggleButton.setText("Chế độ sáng");
                isDarkTheme = true;
            }
            SwingUtilities.updateComponentTreeUI(this);
            this.repaint();
        } catch (Exception e) {
            appendToChatArea("Lỗi chuyển giao diện: " + e.getMessage());
        }
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        if (username.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Vui lòng nhập tên đăng nhập và mật khẩu");
            return;
        }
        try {
            if (!client.isConnected()) client.connect();
            String loginRequest = String.format("{\"action\":\"login\",\"username\":\"%s\",\"password\":\"%s\"}", username, password);
            client.sendMessage(loginRequest);
            statusLabel.setText("Đang đăng nhập...");
        } catch (Exception e) {
            statusLabel.setText("Không thể kết nối: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleRegister() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        if (username.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Vui lòng nhập tên đăng nhập và mật khẩu");
            return;
        }
        try {
            if (!client.isConnected()) client.connect();
            String registerRequest = String.format("{\"action\":\"register\",\"username\":\"%s\",\"password\":\"%s\"}", username, password);
            client.sendMessage(registerRequest);
            statusLabel.setText("Đang tạo tài khoản...");
        } catch (Exception e) {
            statusLabel.setText("Không thể kết nối: " + e.getMessage());
            e.printStackTrace();
        }
    }
private void loadServerPublicKey() {
        try {
            // Sửa đường dẫn này cho đúng với máy của bạn
            String serverKeyPath = "D:\\hk he nam 3\\LTMNC\\laptrinhmang\\laptrinhmang\\src\\main\\java\\com\\example\\client\\server_public.key";
            serverPublicKey = RSAUtils.readPublicKeyFromFile(serverKeyPath);
            appendToChatArea("Hệ thống: Đã tải Public Key của Server thành công.\n");
        } catch (Exception e) {
            serverPublicKey = null;
            appendToChatArea("LỖI NGHIÊM TRỌNG: Không thể tải Public Key của Server. Không thể gửi tin nhắn.\n");
            e.printStackTrace();
        }
    }
      private void handleSendMessage() {
        String message = messageField.getText().trim();
        if (message.isEmpty()) return;

        if (clientPrivateKey == null || clientPublicKey == null || serverPublicKey == null) {
            JOptionPane.showMessageDialog(this,
                    "Thiếu khóa của Client hoặc Server. Không thể gửi tin nhắn an toàn.",
                    "Lỗi Khóa", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Bước 1: Tạo khóa phiên AES ngẫu nhiên
            //Tạo ngẫu nhiên một khóa AES (aesKey) và một IV (vector khởi tạo) cho chế độ AES-CBC.
            SecretKey aesKey = AESUtils.generateAESKey();
            byte[] iv = AESUtils.generateIV();

            // Bước 2: Mã hóa khóa phiên (AES key + IV) bằng Public Key của Server (RSA)
            String sessionKeyString = AESUtils.keyToBase64(aesKey) + ":" + AESUtils.bytesToBase64(iv);
            byte[] encryptedSessionKey = RSAUtils.encrypt(sessionKeyString.getBytes("UTF-8"), serverPublicKey);
            String encryptedSessionKeyBase64 = AESUtils.bytesToBase64(encryptedSessionKey);

            // Bước 3: Chuẩn bị và mã hóa payload bằng khóa phiên AES
            //Ký nội dung tin nhắn bằng RSA Private Key của client.
            byte[] signatureBytes = RSAUtils.sign(message.getBytes("UTF-8"), clientPrivateKey);
            String signatureBase64 = AESUtils.bytesToBase64(signatureBytes);
            //Mã hóa public key của client bằng AES (để server dùng xác thực chữ ký).
            byte[] clientPublicKeyBytes = clientPublicKey.getEncoded();
            byte[] encryptedClientPublicKey = AESUtils.encrypt(clientPublicKeyBytes, aesKey, iv);
            String encryptedClientPublicKeyBase64 = AESUtils.bytesToBase64(encryptedClientPublicKey);

            String innerPayloadJson = String.format(
                "{\"action\":\"send_message\",\"userId\":%d,\"rawMessage\":\"%s\",\"signature\":\"%s\",\"encryptedClientPublicKey\":\"%s\"}",
                currentUserId, message.replace("\"", "\\\""), signatureBase64, encryptedClientPublicKeyBase64
            );
            //Mã hóa toàn bộ payload bên trong bằng AES.
            byte[] encryptedPayloadBytes = AESUtils.encrypt(innerPayloadJson.getBytes("UTF-8"), aesKey, iv);
            String encryptedPayloadBase64 = AESUtils.bytesToBase64(encryptedPayloadBytes);

            // Bước 4: Tạo gói tin cuối cùng để gửi đi
            String finalRequestToServer = String.format(
                "{\"encryptedSessionKey\":\"%s\",\"payload\":\"%s\"}",
                encryptedSessionKeyBase64,
                encryptedPayloadBase64
            );
        //1. Tạo AES Key + IV
//2. Ký nội dung tin nhắn (RSA)
//3. Mã hóa:
   //- AES Key + IV → RSA → encryptedSessionKey
   //- Nội dung tin nhắn + chữ ký + public key → AES → payload
//4. Gửi lên server: {
    //  encryptedSessionKey: "...",
      //payload: "..."
   //}

            client.sendMessage(finalRequestToServer);
            appendToChatArea("Bạn: " + message + "\n");
            messageField.setText("");
        } catch (Exception e) {
            appendToChatArea("Lỗi khi chuẩn bị tin nhắn: " + e.getMessage() + "\n");
            e.printStackTrace();
        }
    }

    private void handleDisconnect() {
        client.disconnect();
        currentUserId = -1;
        CardLayout cl = (CardLayout) mainPanel.getLayout();
        cl.show(mainPanel, "LOGIN");
        usernameField.setText("");
        passwordField.setText("");
        chatArea.setText("");
        messageField.setText("");
        statusLabel.setText("Ngắt kết nối");
        connectionStatusLabel.setText("Đã ngắt kết nối");
    }

    private void appendToChatArea(String message) {
        if (chatArea != null) {
            chatArea.append(message); 
            chatArea.setCaretPosition(chatArea.getDocument().getLength());
        }
    }

    public void handleServerResponse(String response) {
        SwingUtilities.invokeLater(() -> {
            try {
                JsonNode jsonNode = objectMapper.readTree(response);
                String status = jsonNode.get("status").asText();

                switch (status) {
                    case "success":
                        if (jsonNode.has("userId")) {
                             // Xử lý đăng nhập thành công
                            currentUserId = jsonNode.get("userId").asInt();
                            CardLayout cl = (CardLayout) mainPanel.getLayout();
                            cl.show(mainPanel, "CHAT");
                            appendToChatArea("Hệ thống: Đăng nhập thành công\n");
                        } else {
                            // Các tin nhắn thành công khác từ server (bao gồm cả phản hồi của AI)
                            String message = jsonNode.get("message").asText();
                            appendToChatArea(message + "\n");
                        }
                        break;

                    case "error":
                        String errorMessage = jsonNode.get("message").asText();
                        if (currentUserId == -1) {
                            statusLabel.setText(errorMessage); // Lỗi ở màn hình đăng nhập
                        } else {
                            appendToChatArea("Lỗi từ Server: " + errorMessage + "\n");
                        }
                        break;

                    default:
                        // Các tin nhắn thông thường khác (ví dụ từ subdomain scanner)
                        String defaultMessage = jsonNode.has("message") ? jsonNode.get("message").asText() : response;
                        appendToChatArea("Server: " + defaultMessage + "\n");
                        break;
                }
            } catch (Exception e) {
                // Xử lý các trường hợp không phải JSON
                appendToChatArea("Server (raw): " + response + "\n");
            }
        });
    }
    private void addKeyManagementListeners() {
    JFileChooser fileChooser = new JFileChooser();

    // 1. Tạo cặp khóa mới
    generateKeysButton.addActionListener(e -> {
        try {
            KeyPair keyPair = RSAUtils.generateKeyPair();
            clientPrivateKey = keyPair.getPrivate();
            clientPublicKey = keyPair.getPublic();

            privateKeyStatusLabel.setText("Trạng thái: Đã tạo");
            privateKeyStatusLabel.setForeground(SUCCESS_COLOR);
            publicKeyStatusLabel.setText("Trạng thái: Đã tạo");
            publicKeyStatusLabel.setForeground(SUCCESS_COLOR);
            
            // Hỏi người dùng có muốn lưu file không
            int choice = JOptionPane.showConfirmDialog(this, 
                "Tạo cặp khóa thành công! Bạn có muốn lưu chúng ra file không?", 
                "Lưu Khóa", JOptionPane.YES_NO_OPTION);
                
            if (choice == JOptionPane.YES_OPTION) {
                fileChooser.setDialogTitle("Lưu Private Key");
                if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fileChooser.getSelectedFile();
                    Files.write(fileToSave.toPath(), clientPrivateKey.getEncoded());
                }
                
                fileChooser.setDialogTitle("Lưu Public Key");
                if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fileChooser.getSelectedFile();
                    Files.write(fileToSave.toPath(), clientPublicKey.getEncoded());
                }
            }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi tạo khóa: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    });

    // 2. Import Private Key
    importPrivateKeyButton.addActionListener(e -> {
        fileChooser.setDialogTitle("Chọn file Private Key");
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                File selectedFile = fileChooser.getSelectedFile();
                clientPrivateKey = RSAUtils.readPrivateKeyFromFile(selectedFile.getAbsolutePath());
                privateKeyStatusLabel.setText("Trạng thái: Đã tải");
                privateKeyStatusLabel.setForeground(SUCCESS_COLOR);
            } catch (Exception ex) {
                clientPrivateKey = null;
                privateKeyStatusLabel.setText("Trạng thái: Lỗi tải file");
                privateKeyStatusLabel.setForeground(DANGER_COLOR);
                JOptionPane.showMessageDialog(this, "Không thể đọc Private Key từ file đã chọn.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    });

    // 3. Import Public Key
    importPublicKeyButton.addActionListener(e -> {
        fileChooser.setDialogTitle("Chọn file Public Key");
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                File selectedFile = fileChooser.getSelectedFile();
                clientPublicKey = RSAUtils.readPublicKeyFromFile(selectedFile.getAbsolutePath());
                publicKeyStatusLabel.setText("Trạng thái: Đã tải");
                publicKeyStatusLabel.setForeground(SUCCESS_COLOR);
            } catch (Exception ex) {
                clientPublicKey = null;
                publicKeyStatusLabel.setText("Trạng thái: Lỗi tải file");
                publicKeyStatusLabel.setForeground(DANGER_COLOR);
                JOptionPane.showMessageDialog(this, "Không thể đọc Public Key từ file đã chọn.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    });
}


    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        SwingUtilities.invokeLater(() -> {
            new ClientGUI().setVisible(true);
        });
    }
}