package com.example.server;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

import javax.crypto.SecretKey;

import com.example.database.DatabaseManager; // Giả sử bạn có class này
import com.example.utils.AESUtils;
import com.example.utils.RSAUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

public class ServerHandler extends ChannelInboundHandlerAdapter {
    private final ObjectMapper objectMapper = new ObjectMapper();
    private DatabaseManager dbManager;
    private final PrivateKey serverPrivateKey;
    private static final Map<ChannelHandlerContext, SubdomainScanner> activeScanners = new ConcurrentHashMap<>();

    public ServerHandler(PrivateKey serverPrivateKey) {
        this.serverPrivateKey = serverPrivateKey;
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("Client connected: " + ctx.channel().remoteAddress());
        dbManager = new DatabaseManager();
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        String message = (String) msg;
        System.out.println("Received raw wrapper: " + message);

        try {
            JsonNode wrapperNode = objectMapper.readTree(message);

            if (wrapperNode.has("encryptedSessionKey") && wrapperNode.has("payload")) {
                // Giải mã khóa phiên AES bằng Private Key của Server (RSA)
                String encryptedSessionKeyBase64 = wrapperNode.get("encryptedSessionKey").asText();
                byte[] encryptedSessionKeyBytes = AESUtils.base64ToBytes(encryptedSessionKeyBase64);
                byte[] decryptedSessionKeyBytes = RSAUtils.decrypt(encryptedSessionKeyBytes, this.serverPrivateKey);
                String sessionKeyString = new String(decryptedSessionKeyBytes, "UTF-8");
                
                String[] parts = sessionKeyString.split(":");
                String aesKeyBase64 = parts[0];
                String ivBase64 = parts[1];
                SecretKey aesKey = AESUtils.base64ToKey(aesKeyBase64);
                byte[] iv = AESUtils.base64ToBytes(ivBase64);

                // Dùng khóa phiên để giải mã payload
                String encryptedPayloadBase64 = wrapperNode.get("payload").asText();
                byte[] encryptedPayloadBytes = AESUtils.base64ToBytes(encryptedPayloadBase64);
                byte[] decryptedPayloadBytes = AESUtils.decrypt(encryptedPayloadBytes, aesKey, iv);
                String decryptedPayloadJson = new String(decryptedPayloadBytes, "UTF-8");
                System.out.println("Decrypted Inner JSON: " + decryptedPayloadJson);

                JsonNode innerJsonNode = objectMapper.readTree(decryptedPayloadJson);
                String action = innerJsonNode.get("action").asText();
                
                if ("send_message".equals(action)) {
                    handleSendMessage(ctx, innerJsonNode, aesKey, iv, aesKeyBase64, ivBase64);
                }
            } else if (wrapperNode.has("action")) {
                String action = wrapperNode.get("action").asText();
                switch (action) {
                    case "register": handleRegister(ctx, wrapperNode); break;
                    case "login": handleLogin(ctx, wrapperNode); break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            ctx.writeAndFlush("{\"status\":\"error\",\"message\":\"Invalid request format or decryption failed\"}");
        }
    }

    private void handleRegister(ChannelHandlerContext ctx, JsonNode jsonNode) throws Exception {
        String username = jsonNode.get("username").asText();
        String password = jsonNode.get("password").asText();
        boolean success = dbManager.registerUser(username, password);
        if (success) {
            ctx.writeAndFlush("{\"status\":\"success\",\"message\":\"User registered successfully\"}");
        } else {
            ctx.writeAndFlush("{\"status\":\"error\",\"message\":\"Username already exists\"}");
        }
    }

    private void handleLogin(ChannelHandlerContext ctx, JsonNode jsonNode) throws Exception {
        String username = jsonNode.get("username").asText();
        String password = jsonNode.get("password").asText();
        int userId = dbManager.loginUser(username, password);
        if (userId != -1) {
            ctx.writeAndFlush("{\"status\":\"success\",\"message\":\"Login successful\",\"userId\":" + userId + "}");
        } else {
            ctx.writeAndFlush("{\"status\":\"error\",\"message\":\"Invalid credentials\"}");
        }
    }

private void handleSendMessage(ChannelHandlerContext ctx, JsonNode jsonNode, SecretKey aesKey, byte[] iv, String aesKeyBase64, String ivBase64) throws Exception {
        int userId = jsonNode.get("userId").asInt();
        String rawMessage = jsonNode.get("rawMessage").asText();
        String signatureBase64 = jsonNode.get("signature").asText();
        String encryptedClientPublicKeyBase64 = jsonNode.get("encryptedClientPublicKey").asText();

        boolean isVerified = false;
        String verificationError = "Unknown error.";

        try {
            byte[] encryptedClientPublicKeyBytes = AESUtils.base64ToBytes(encryptedClientPublicKeyBase64);
            byte[] clientPublicKeyBytes = AESUtils.decrypt(encryptedClientPublicKeyBytes, aesKey, iv);

            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(clientPublicKeyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PublicKey verificationKey = keyFactory.generatePublic(keySpec);

            isVerified = RSAUtils.verify(rawMessage.getBytes("UTF-8"), AESUtils.base64ToBytes(signatureBase64), verificationKey);

            if (!isVerified) verificationError = "Signature mismatch.";
        } catch (Exception e) {
            verificationError = "Failed to decrypt/verify. Error: " + e.getMessage();
            isVerified = false;
        }
        
        System.out.println("Verification result for userId " + userId + ": " + isVerified);

    // === BƯỚC 3: RẼ NHÁNH DỰA TRÊN KẾT QUẢ (Logic này không đổi) ===
    if (isVerified) {
        if (dbManager != null) {
            // Lưu key AES và IV vào DB SAU KHI đã xác thực thành công.
            dbManager.saveClientKeys(userId, aesKeyBase64, ivBase64);
        }
        dbManager.saveChatHistory(userId, rawMessage, "pending_response", signatureBase64, isVerified);

        if (activeScanners.containsKey(ctx)) {
            ctx.writeAndFlush("{\"status\":\"error\",\"message\":\"Một tiến trình quét đang chạy. Vui lòng đợi hoàn tất.\"}");
            return;
        }

        String domainToScan = extractDomain(rawMessage);
        if (domainToScan != null && !domainToScan.isEmpty()) {
            ctx.writeAndFlush("{\"status\":\"success\",\"message\":\"VERIFICATION_SUCCESSFUL. Starting scan for " + domainToScan + "...\"}");
            Consumer<ChannelHandlerContext> onComplete = activeScanners::remove;
            SubdomainScanner scanner = new SubdomainScanner(domainToScan, ctx, onComplete);
            activeScanners.put(ctx, scanner);
            scanner.startScan();
        } else {
                // CHỨC NĂNG 2: CHAT VỚI AI
                try {
                    ctx.writeAndFlush("{\"status\":\"success\",\"message\":\"VERIFICATION_SUCCESSFUL.\"}");
                    System.out.println("User prompt for AI: " + rawMessage);
                    ChatAI chatAI = new ChatAI();
                    String aiResponseText = chatAI.generateContent(rawMessage);
                    String fullMessage = "AI: " + aiResponseText;
                    String jsonResponse = String.format("{\"status\":\"success\", \"message\": %s}", objectMapper.writeValueAsString(fullMessage));
                    ctx.writeAndFlush(jsonResponse);
                    System.out.println("Sent full AI response to client.");
                } catch (Exception e) {
                    System.err.println("AI service error: " + e.getMessage());
                    ctx.writeAndFlush("{\"status\":\"error\",\"message\":\"AI service error.\"}");
                }
            }
        } else {
            String jsonErrorResponse = String.format(
            "{\"status\":\"error\",\"message\":\"VERIFICATION_FAILED: %s\"}",
            verificationError.replace("\"", "'") // Thay thế dấu ngoặc kép để tránh làm hỏng JSON
        );
        
        System.out.println("Sending failure response to client: " + jsonErrorResponse); // Log chẩn đoán
        ctx.writeAndFlush(jsonErrorResponse);
    }
}

    private String extractDomain(String message) {
        if (message != null && message.contains("https://")) {
            try {
                int start = message.indexOf("https://") + 8;
                int end = message.indexOf("/", start);
                if (end == -1) { end = message.length(); }
                return message.substring(start, end).trim();
            } catch (Exception e) {
                System.err.println("Error extracting domain: " + e.getMessage());
                return null;
            }
        }
        return null;
    }
    
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("Client disconnected: " + ctx.channel().remoteAddress());
        if (activeScanners.containsKey(ctx)) { activeScanners.get(ctx).stopScan(); activeScanners.remove(ctx); }
        if (dbManager != null) { dbManager.close(); }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        if (activeScanners.containsKey(ctx)) { activeScanners.get(ctx).stopScan(); activeScanners.remove(ctx); }
        if (dbManager != null) { dbManager.close(); }
        ctx.close();
    }
}