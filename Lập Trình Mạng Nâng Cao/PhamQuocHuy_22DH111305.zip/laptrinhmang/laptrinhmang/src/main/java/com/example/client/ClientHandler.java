// File: com/example/client/ClientHandler.java

package com.example.client;

import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext; // <-- 1. THÊM IMPORT NÀY
import io.netty.channel.SimpleChannelInboundHandler;

@Sharable // <-- 2. THÊM ANNOTATION NÀY
public class ClientHandler extends SimpleChannelInboundHandler<String> {

    private ClientGUI clientGUI;

    // Method to set the GUI reference
    public void setClientGUI(ClientGUI clientGUI) {
        this.clientGUI = clientGUI;
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, String msg) throws Exception {
        System.out.println("Received from server: " + msg);
        if (clientGUI != null) {
            clientGUI.handleServerResponse(msg);
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        cause.printStackTrace();
        if (clientGUI != null) {
            clientGUI.handleServerResponse("{\"status\":\"error\",\"message\":\"Connection error: " + cause.getMessage() + "\"}");
        }
        ctx.close();
    }
}